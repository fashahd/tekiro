<main id="main" class="">
<div id="content-contact" class="content-area page-wrapper" role="main">
	<div class="row row-main">
		<div class="large-12 col">
			<div class="col-inner">
				
				
														
						<div class="vc_row wpb_row vc_row-fluid vc_custom_1501532673163"><div class="wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element " >
		<div class="wpb_wrapper">
			<div class="container section-title-container" ><h3 class="section-title section-title-bold-center"><b></b><span class="section-title-main" >WRITE YOUR MESSAGE</span><b></b></h3></div><!-- .section-title -->

		</div>
	</div>
<div class="vc_row wpb_row vc_inner vc_row-fluid vc_row-o-equal-height vc_row-o-content-top vc_row-flex"><div class="wpb_column vc_column_container vc_col-sm-6"><div class="vc_column-inner vc_custom_1501533492866"><div class="wpb_wrapper"><div role="form" class="wpcf7" id="wpcf7-f5-p2634-o1" lang="en-US" dir="ltr">
<div class="screen-reader-response"></div>
<form action="/contact/#wpcf7-f5-p2634-o1" method="post" class="wpcf7-form mailchimp-ext-0.4.51" enctype="multipart/form-data" novalidate="novalidate">
<div style="display: none;">
<input type="hidden" name="_wpcf7" value="5" />
<input type="hidden" name="_wpcf7_version" value="5.0.1" />
<input type="hidden" name="_wpcf7_locale" value="en_US" />
<input type="hidden" name="_wpcf7_unit_tag" value="wpcf7-f5-p2634-o1" />
<input type="hidden" name="_wpcf7_container_post" value="2634" />
</div>
<div class="column one-third"><span class="wpcf7-form-control-wrap your-name"><input type="text" name="your-name" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required" aria-required="true" aria-invalid="false" placeholder="Your Name" /></span> </div>
<div class="column one-third"><span class="wpcf7-form-control-wrap your-email"><input type="email" name="your-email" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-email wpcf7-validates-as-required wpcf7-validates-as-email" aria-required="true" aria-invalid="false" placeholder="Email Address" /></span> </div>
<div class="column one-third"><span class="wpcf7-form-control-wrap ph"><input type="tel" name="ph" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-tel wpcf7-validates-as-required wpcf7-validates-as-tel" aria-required="true" aria-invalid="false" placeholder="Contact Number" /></span> </div>
<div class="column one"><b>Department : </b><span class="wpcf7-form-control-wrap departemen"><select name="departemen" class="wpcf7-form-control wpcf7-select wpcf7-validates-as-required" aria-required="true" aria-invalid="false"><option value="">---</option><option value="Sales &amp; Marketing">Sales &amp; Marketing</option><option value="Event">Event</option></select></span></div>
<div class="column one"><span class="wpcf7-form-control-wrap your-subject"><input type="text" name="your-subject" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required" aria-required="true" aria-invalid="false" placeholder="Subject" /></span> </div>
<div class="column one"><span class="wpcf7-form-control-wrap your-message"><textarea name="your-message" cols="40" rows="5" class="wpcf7-form-control wpcf7-textarea" aria-invalid="false" placeholder="Write your message..."></textarea></span></div>
<div class="column one"><span class="wpcf7-form-control-wrap your-file"><input type="file" name="your-file" size="40" class="wpcf7-form-control wpcf7-file" accept=".pdf,.png,.jpeg,.jpg,.ppt,.pptx,.doc,.docx" aria-invalid="false" /></span> <i>*Only file .pdf, .png, .jpeg, .jpg, .ppt, .pptx, .doc, and/or .docx (max. 5mb)</i></div>
<div class="column one">
<div class="wpcf7-form-control-wrap"><div data-sitekey="6LcFJSMUAAAAAOpz39VsuHqnH99klENJIjYus-_d" data-theme="dark" class="wpcf7-form-control g-recaptcha wpcf7-recaptcha"></div>
<noscript>
	<div style="width: 302px; height: 422px;">
		<div style="width: 302px; height: 422px; position: relative;">
			<div style="width: 302px; height: 422px; position: absolute;">
				<iframe src="https://www.google.com/recaptcha/api/fallback?k=6LcFJSMUAAAAAOpz39VsuHqnH99klENJIjYus-_d" frameborder="0" scrolling="no" style="width: 302px; height:422px; border-style: none;">
				</iframe>
			</div>
			<div style="width: 300px; height: 60px; border-style: none; bottom: 12px; left: 25px; margin: 0px; padding: 0px; right: 25px; background: #f9f9f9; border: 1px solid #c1c1c1; border-radius: 3px;">
				<textarea id="g-recaptcha-response" name="g-recaptcha-response" class="g-recaptcha-response" style="width: 250px; height: 40px; border: 1px solid #c1c1c1; margin: 10px 25px; padding: 0px; resize: none;">
				</textarea>
			</div>
		</div>
	</div>
</noscript>
</div>
</div>
<div class="column one"><input type="submit" value="Send Message" class="wpcf7-form-control wpcf7-submit" /></div>
<div class="wpcf7-response-output wpcf7-display-none"></div><p style="display: none !important"><span class="wpcf7-form-control-wrap referer-page"><input type="hidden" name="referer-page" value="https://tekiro.com/events/" class="wpcf7-form-control wpcf7-text referer-page" aria-invalid="false"></span></p>
<!-- Chimpmail extension by Renzo Johnson --></form></div></div></div></div><div class="wpb_column vc_column_container vc_col-sm-6"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element " >
		<div class="wpb_wrapper">
			<p>Please select the department you want to reach accordingly to ensure quick response.</p>
<p>For general info about products and sales territories, please click on the following link to connect directly to our social media : <a href="https://m.me/TekiroTools/" target="_blank" rel="noopener"><strong>GENERAL QUESTIONS</strong></a></p>
<p>We try our best to provide accurate recommendations and answer to your enquiry as soon as possible. Thank you for your patience and cooperation.</p>
<p>Regards,<br />
<img class="alignleft wp-image-2327" src="https://tekiro.com/wp-content/uploads/logo-1.png" alt="" width="150" height="45" /></p>

		</div>
	</div>
</div></div></div></div></div></div></div></div>

						
												</div><!-- .col-inner -->
		</div><!-- .large-12 -->
	</div><!-- .row -->
</div>


</main>