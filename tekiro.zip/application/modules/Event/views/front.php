<main id="main" class="">
<div id="content-event" class="content-area page-wrapper" role="main">
	<div class="row row-main">
		<div class="large-12 col">
			<div class="col-inner">
				
				
														
						<div class="vc_row wpb_row vc_row-fluid"><div class="wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper"><div class="vc_empty_space" style="height: 32px"><span class="vc_empty_space_inner"></span></div>
<!-- vc_grid start -->
<div class="vc_grid-container-wrapper vc_clearfix">
	<div class="vc_grid-container vc_clearfix wpb_content_element vc_basic_grid" data-initial-loading-animation="none" data-vc-grid-settings="{&quot;page_id&quot;:2639,&quot;style&quot;:&quot;all&quot;,&quot;action&quot;:&quot;vc_get_vc_grid_data&quot;,&quot;shortcode_id&quot;:&quot;1513665319636-8871aa49-d636-0&quot;,&quot;tag&quot;:&quot;vc_basic_grid&quot;}" data-vc-request="https://tekiro.com/altama-admin/admin-ajax.php" data-vc-post-id="2639" data-vc-public-nonce="afdb34ed6a">
	<style type="text/css" data-type="vc_shortcodes-custom-css">.vc_custom_1508716776232{border-top-width: 4px !important;border-right-width: 4px !important;border-bottom-width: 4px !important;border-left-width: 4px !important;background-color: #ffffff !important;background-position: center !important;background-repeat: no-repeat !important;background-size: cover !important;border-left-color: #0a0a0a !important;border-left-style: double !important;border-right-color: #0a0a0a !important;border-right-style: double !important;border-top-color: #0a0a0a !important;border-top-style: double !important;border-bottom-color: #0a0a0a !important;border-bottom-style: double !important;}.vc_custom_1419002184955{padding-right: 15px !important;padding-left: 15px !important;}</style><style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
<link rel="stylesheet" id="vc_google_fonts_roboto100100italic300300italicregularitalic500500italic700700italic900900italic-css" href="//fonts.googleapis.com/css?family=Roboto%3A100%2C100italic%2C300%2C300italic%2Cregular%2Citalic%2C500%2C500italic%2C700%2C700italic%2C900%2C900italic&amp;ver=4.9.10" type="text/css" media="all">
<div class="vc_grid vc_row vc_grid-gutter-30px vc_pageable-wrapper vc_hook_hover" data-vc-pageable-content="true"><div class="vc_pageable-slide-wrapper vc_clearfix" data-vc-grid-content="true"><div class="vc_grid-item vc_clearfix vc_col-sm-4 vc_visible-item"><div class="vc_grid-item-mini vc_clearfix"><div class="vc_gitem-animated-block  vc_gitem-animate vc_gitem-animate-flipHorizontalFadeIn" data-vc-animation="flipHorizontalFadeIn"><div class="vc_gitem-zone vc_gitem-zone-a vc-gitem-zone-height-mode-auto vc-gitem-zone-height-mode-auto-16-9 vc_gitem-is-link" style="background-image: url('https://tekiro.com/wp-content/uploads/19665408_1410682175682279_2109395747920544663_n.jpg') !important;">
	<a href="https://tekiro.com/tekiro-truck-mobile-display-2/" title="TEKIRO Truck Mobile Display – Roadshow Schedule" class="vc_gitem-link vc-zone-link"></a>	<img src="https://tekiro.com/wp-content/uploads/19665408_1410682175682279_2109395747920544663_n.jpg" class="vc_gitem-zone-img" alt="">	<div class="vc_gitem-zone-mini">
			</div>
</div>
<div class="vc_gitem-zone vc_gitem-zone-b vc_custom_1508716776232 vc-gitem-zone-height-mode-auto vc_gitem-is-link">
	<a href="https://tekiro.com/tekiro-truck-mobile-display-2/" title="TEKIRO Truck Mobile Display – Roadshow Schedule" class="vc_gitem-link vc-zone-link"></a>		<div class="vc_gitem-zone-mini">
		<div class="vc_gitem_row vc_row vc_gitem-row-position-middle"><div class="vc_col-sm-12 vc_gitem-col vc_gitem-col-align- vc_custom_1419002184955"><div class="vc_custom_heading vc_gitem-post-data vc_gitem-post-data-source-post_date"><div style="font-size: 12px;color: #333333;line-height: 1.3;text-align: center;font-family:Roboto;font-weight:400;font-style:normal">21 August 17</div></div><div class="vc_custom_heading vc_gitem-post-data vc_gitem-post-data-source-post_title"><div style="font-size: 24px;color: #0db14b;line-height: 1.3;text-align: center;font-family:Roboto;font-weight:700;font-style:normal">TEKIRO Truck Mobile Display – Roadshow Schedule</div></div></div></div>	</div>
</div>
</div>
</div><div class="vc_clearfix"></div></div><div class="vc_grid-item vc_clearfix vc_col-sm-4 vc_visible-item"><div class="vc_grid-item-mini vc_clearfix"><div class="vc_gitem-animated-block  vc_gitem-animate vc_gitem-animate-flipHorizontalFadeIn" data-vc-animation="flipHorizontalFadeIn"><div class="vc_gitem-zone vc_gitem-zone-a vc-gitem-zone-height-mode-auto vc-gitem-zone-height-mode-auto-16-9 vc_gitem-is-link" style="background-image: url('https://tekiro.com/wp-content/uploads/GIIAS-2017.jpg') !important;">
	<a href="https://tekiro.com/gaikindo-indonesia-international-motor-show-2017/" title="GAIKINDO Indonesia International Motor Show 2017" class="vc_gitem-link vc-zone-link"></a>	<img src="https://tekiro.com/wp-content/uploads/GIIAS-2017.jpg" class="vc_gitem-zone-img" alt="GIIAS 2017">	<div class="vc_gitem-zone-mini">
			</div>
</div>
<div class="vc_gitem-zone vc_gitem-zone-b vc_custom_1508716776232 vc-gitem-zone-height-mode-auto vc_gitem-is-link">
	<a href="https://tekiro.com/gaikindo-indonesia-international-motor-show-2017/" title="GAIKINDO Indonesia International Motor Show 2017" class="vc_gitem-link vc-zone-link"></a>		<div class="vc_gitem-zone-mini">
		<div class="vc_gitem_row vc_row vc_gitem-row-position-middle"><div class="vc_col-sm-12 vc_gitem-col vc_gitem-col-align- vc_custom_1419002184955"><div class="vc_custom_heading vc_gitem-post-data vc_gitem-post-data-source-post_date"><div style="font-size: 12px;color: #333333;line-height: 1.3;text-align: center;font-family:Roboto;font-weight:400;font-style:normal">9 August 17</div></div><div class="vc_custom_heading vc_gitem-post-data vc_gitem-post-data-source-post_title"><div style="font-size: 24px;color: #0db14b;line-height: 1.3;text-align: center;font-family:Roboto;font-weight:700;font-style:normal">GAIKINDO Indonesia International Motor Show 2017</div></div></div></div>	</div>
</div>
</div>
</div><div class="vc_clearfix"></div></div><div class="vc_grid-item vc_clearfix vc_col-sm-4 vc_visible-item"><div class="vc_grid-item-mini vc_clearfix "><div class="vc_gitem-animated-block  vc_gitem-animate vc_gitem-animate-flipHorizontalFadeIn" data-vc-animation="flipHorizontalFadeIn"><div class="vc_gitem-zone vc_gitem-zone-a vc-gitem-zone-height-mode-auto vc-gitem-zone-height-mode-auto-16-9 vc_gitem-is-link" style="background-image: url('https://tekiro.com/wp-content/uploads/IMG_3969-27-05-17-16-04-e1495876326294-1024x576.jpeg') !important;">
	<a href="https://tekiro.com/indonesia-international-motor-show-2017-2/" title="Indonesia International Motor Show 2017" class="vc_gitem-link vc-zone-link"></a>	<img src="https://tekiro.com/wp-content/uploads/IMG_3969-27-05-17-16-04-e1495876326294-1024x576.jpeg" class="vc_gitem-zone-img" alt="TEKIRO Tools IIMS 2017">	<div class="vc_gitem-zone-mini">
			</div>
</div>
<div class="vc_gitem-zone vc_gitem-zone-b vc_custom_1508716776232 vc-gitem-zone-height-mode-auto vc_gitem-is-link">
	<a href="https://tekiro.com/indonesia-international-motor-show-2017-2/" title="Indonesia International Motor Show 2017" class="vc_gitem-link vc-zone-link"></a>		<div class="vc_gitem-zone-mini">
		<div class="vc_gitem_row vc_row vc_gitem-row-position-middle"><div class="vc_col-sm-12 vc_gitem-col vc_gitem-col-align- vc_custom_1419002184955"><div class="vc_custom_heading vc_gitem-post-data vc_gitem-post-data-source-post_date"><div style="font-size: 12px;color: #333333;line-height: 1.3;text-align: center;font-family:Roboto;font-weight:400;font-style:normal">27 April 17</div></div><div class="vc_custom_heading vc_gitem-post-data vc_gitem-post-data-source-post_title"><div style="font-size: 24px;color: #0db14b;line-height: 1.3;text-align: center;font-family:Roboto;font-weight:700;font-style:normal">Indonesia International Motor Show 2017</div></div></div></div>	</div>
</div>
</div>
</div><div class="vc_clearfix"></div></div><div class="vc_grid-item vc_clearfix vc_col-sm-4 vc_visible-item"><div class="vc_grid-item-mini vc_clearfix"><div class="vc_gitem-animated-block  vc_gitem-animate vc_gitem-animate-flipHorizontalFadeIn" data-vc-animation="flipHorizontalFadeIn"><div class="vc_gitem-zone vc_gitem-zone-a vc-gitem-zone-height-mode-auto vc-gitem-zone-height-mode-auto-16-9 vc_gitem-is-link" style="background-image: url('https://tekiro.com/wp-content/uploads/tim-bumi-siliwangi-1024x576.jpg') !important;">
	<a href="https://tekiro.com/shell-eco-marathon-asia-2017-universitas-pendidikan-indonesia-2/" title="Shell Eco Marathon Asia (Bumi Siliwangi 1 Team)" class="vc_gitem-link vc-zone-link"></a>	<img src="https://tekiro.com/wp-content/uploads/tim-bumi-siliwangi-1024x576.jpg" class="vc_gitem-zone-img" alt="tim-bumi-siliwangi">	<div class="vc_gitem-zone-mini">
			</div>
</div>
<div class="vc_gitem-zone vc_gitem-zone-b vc_custom_1508716776232 vc-gitem-zone-height-mode-auto vc_gitem-is-link">
	<a href="https://tekiro.com/shell-eco-marathon-asia-2017-universitas-pendidikan-indonesia-2/" title="Shell Eco Marathon Asia (Bumi Siliwangi 1 Team)" class="vc_gitem-link vc-zone-link"></a>		<div class="vc_gitem-zone-mini">
		<div class="vc_gitem_row vc_row vc_gitem-row-position-middle"><div class="vc_col-sm-12 vc_gitem-col vc_gitem-col-align- vc_custom_1419002184955"><div class="vc_custom_heading vc_gitem-post-data vc_gitem-post-data-source-post_date"><div style="font-size: 12px;color: #333333;line-height: 1.3;text-align: center;font-family:Roboto;font-weight:400;font-style:normal">16 March 17</div></div><div class="vc_custom_heading vc_gitem-post-data vc_gitem-post-data-source-post_title"><div style="font-size: 24px;color: #0db14b;line-height: 1.3;text-align: center;font-family:Roboto;font-weight:700;font-style:normal">Shell Eco Marathon Asia (Bumi Siliwangi 1 Team)</div></div></div></div>	</div>
</div>
</div>
</div><div class="vc_clearfix"></div></div><div class="vc_grid-item vc_clearfix vc_col-sm-4 vc_visible-item"><div class="vc_grid-item-mini vc_clearfix "><div class="vc_gitem-animated-block  vc_gitem-animate vc_gitem-animate-flipHorizontalFadeIn" data-vc-animation="flipHorizontalFadeIn"><div class="vc_gitem-zone vc_gitem-zone-a vc-gitem-zone-height-mode-auto vc-gitem-zone-height-mode-auto-16-9 vc_gitem-is-link" style="background-image: url('https://tekiro.com/wp-content/uploads/ETU-2017-Surabaya-1024x501.jpg') !important;">
	<a href="https://tekiro.com/engine-tune-up-etu-2017-surabaya-by-its/" title="Engine Tune Up (ETU) 2017 Surabaya by ITS" class="vc_gitem-link vc-zone-link"></a>	<img src="https://tekiro.com/wp-content/uploads/ETU-2017-Surabaya-1024x501.jpg" class="vc_gitem-zone-img" alt="ETU 2017 Surabaya">	<div class="vc_gitem-zone-mini">
			</div>
</div>
<div class="vc_gitem-zone vc_gitem-zone-b vc_custom_1508716776232 vc-gitem-zone-height-mode-auto vc_gitem-is-link">
	<a href="https://tekiro.com/engine-tune-up-etu-2017-surabaya-by-its/" title="Engine Tune Up (ETU) 2017 Surabaya by ITS" class="vc_gitem-link vc-zone-link"></a>		<div class="vc_gitem-zone-mini">
		<div class="vc_gitem_row vc_row vc_gitem-row-position-middle"><div class="vc_col-sm-12 vc_gitem-col vc_gitem-col-align- vc_custom_1419002184955"><div class="vc_custom_heading vc_gitem-post-data vc_gitem-post-data-source-post_date"><div style="font-size: 12px;color: #333333;line-height: 1.3;text-align: center;font-family:Roboto;font-weight:400;font-style:normal">11 February 17</div></div><div class="vc_custom_heading vc_gitem-post-data vc_gitem-post-data-source-post_title"><div style="font-size: 24px;color: #0db14b;line-height: 1.3;text-align: center;font-family:Roboto;font-weight:700;font-style:normal">Engine Tune Up (ETU) 2017 Surabaya by ITS</div></div></div></div>	</div>
</div>
</div>
</div><div class="vc_clearfix"></div></div></div></div></div>
</div><!-- vc_grid end -->
</div></div></div></div>

						
												</div><!-- .col-inner -->
		</div><!-- .large-12 -->
	</div><!-- .row -->
</div>


</main>