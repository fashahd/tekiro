<main id="main" class="">
<div id="content-product" class="content-area page-wrapper" role="main">
	<div class="row row-main">
		<div class="large-12 col">
			<div class="col-inner">
				
				
														
						<div class="vc_row wpb_row vc_row-fluid"><div class="wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper"><div class="vc_row wpb_row vc_inner vc_row-fluid vc_custom_1501544643346 vc_row-has-fill"><div class="wpb_column vc_column_container vc_col-sm-12 vc_hidden-lg vc_hidden-md"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element " >
		<div class="wpb_wrapper">
			<p style="text-align: center;"><div class="message-box relative dark" style="padding-top:15px;padding-bottom:15px;"><div class="message-box-bg-image bg-fill fill" style="background-image:url(#0DB14B);"></div><div class="message-box-bg-overlay bg-fill fill" ></div><div class="container relative"><div class="inner last-reset"><em>Use potrait mode for better experience when open the catalog</em></div></div></div>

		</div>
	</div>
</div></div></div></div><div class="vc_row wpb_row vc_inner vc_row-fluid vc_row-o-equal-height vc_row-o-content-bottom vc_row-flex"><div class="wpb_column vc_column_container vc_col-sm-3"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element " >
		<div class="wpb_wrapper">
			<p style="text-align: center;"><div class="_df_thumb " id="df_3148"  wpoptions=true thumb=https://tekiro.com/wp-content/uploads/Wrenches-1.jpg >Wrench</div><script data-cfasync="false">var option_df_3148 = {"outline":[],"forceFit":"true","autoEnableOutline":"false","autoEnableThumbnail":"false","overwritePDFOutline":"false","direction":"1","pageMode":"0","source":"<?=base_url()?>appsources/files/01-Wrenches.pdf","wpOptions":"true"};</script></p>
<h2 style="text-align: center;">Wrenches</h2>
<p style="text-align: center;"><a href="<?=base_url()?>appsources/files/01-Wrenches.pdf" target="_blank" class="button primary is-primary is-medium"  >
    <span>DOWNLOAD &amp; PRINT</span>
  </a>
</p>

		</div>
	</div>
</div></div></div><div class="wpb_column vc_column_container vc_col-sm-3"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element " >
		<div class="wpb_wrapper">
			<p style="text-align: center;"><div class="_df_thumb " id="df_3150"  wpoptions=true thumb=https://tekiro.com/wp-content/uploads/Torque_Socket-1.jpg >Torque &#038; Sockets</div><script data-cfasync="false">var option_df_3150 = {"outline":[],"forceFit":"true","autoEnableOutline":"false","autoEnableThumbnail":"false","overwritePDFOutline":"false","direction":"1","pageMode":"0","source":"<?=base_url()?>appsources/files/02-Torque-and-Socket_optimize.pdf","wpOptions":"true"};</script></p>
<h2 style="text-align: center;">Torque &amp; Sockets</h2>
<p style="text-align: center;"><a href="<?=base_url()?>appsources/files/02-Torque-and-Socket_optimize.pdf" target="_blank" class="button primary is-primary is-medium"  >
    <span>DOWNLOAD &amp; PRINT</span>
  </a>
</p>

		</div>
	</div>
</div></div></div><div class="wpb_column vc_column_container vc_col-sm-3"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element " >
		<div class="wpb_wrapper">
			<p style="text-align: center;"><div class="_df_thumb " id="df_3152"  wpoptions=true thumb=https://tekiro.com/wp-content/uploads/Impact_socket-1.jpg >Impact Sockets</div><script data-cfasync="false">var option_df_3152 = {"outline":[],"forceFit":"true","autoEnableOutline":"false","autoEnableThumbnail":"false","overwritePDFOutline":"false","direction":"1","pageMode":"0","source":"<?=base_url()?>appsources/files/03-Impact-Socket_optimize.pdf","wpOptions":"true"};</script></p>
<h2 style="text-align: center;">Impact Socket</h2>
<p style="text-align: center;"><a href="<?=base_url()?>appsources/files/03-Impact-Socket_optimize.pdf" target="_blank" class="button primary is-primary is-medium"  >
    <span>DOWNLOAD &amp; PRINT</span>
  </a>
</p>

		</div>
	</div>
</div></div></div><div class="wpb_column vc_column_container vc_col-sm-3"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element " >
		<div class="wpb_wrapper">
			<p style="text-align: center;"><div class="_df_thumb " id="df_3154"  wpoptions=true thumb=https://tekiro.com/wp-content/uploads/Pliers-1.jpg >Pliers</div><script data-cfasync="false">var option_df_3154 = {"outline":[],"forceFit":"true","autoEnableOutline":"false","autoEnableThumbnail":"false","overwritePDFOutline":"false","direction":"1","pageMode":"0","source":"<?=base_url()?>appsources/files/04-Pliers-TEKIRO-Tools-1.pdf","wpOptions":"true"};</script></p>
<h2 style="text-align: center;">Pliers</h2>
<p style="text-align: center;"><a href="<?=base_url()?>appsources/files/04-Pliers-TEKIRO-Tools-1.pdf" target="_blank" class="button primary is-primary is-medium"  >
    <span>DOWNLOAD &amp; PRINT</span>
  </a>
</p>

		</div>
	</div>
</div></div></div></div></div></div></div></div><div class="vc_row wpb_row vc_row-fluid vc_custom_1501312843970 vc_row-has-fill"><div class="wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper"><div class="vc_row wpb_row vc_inner vc_row-fluid vc_row-o-equal-height vc_row-o-content-bottom vc_row-flex"><div class="wpb_column vc_column_container vc_col-sm-3"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element " >
		<div class="wpb_wrapper">
			<p style="text-align: center;"><div class="_df_thumb " id="df_3156"  wpoptions=true thumb=https://tekiro.com/wp-content/uploads/Screwdrivers-1.jpg >Screwdrivers</div><script data-cfasync="false">var option_df_3156 = {"outline":[],"forceFit":"true","autoEnableOutline":"false","autoEnableThumbnail":"false","overwritePDFOutline":"false","direction":"1","pageMode":"0","source":"<?=base_url()?>appsources/files/05-Screwdrivers-TEKIRO-Tools.pdf","wpOptions":"true"};</script></p>
<h2 style="text-align: center;">Screwdrivers</h2>
<p style="text-align: center;"><a href="<?=base_url()?>appsources/files/05-Screwdrivers-TEKIRO-Tools.pdf" target="_blank" class="button primary is-primary is-medium"  >
    <span>DOWNLOAD &amp; PRINT</span>
  </a>
</p>

		</div>
	</div>
</div></div></div><div class="wpb_column vc_column_container vc_col-sm-3"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element " >
		<div class="wpb_wrapper">
			<p style="text-align: center;"><div class="_df_thumb " id="df_3158"  wpoptions=true thumb=https://tekiro.com/wp-content/uploads/Automotive-1.jpg >Automotive</div><script data-cfasync="false">var option_df_3158 = {"outline":[],"forceFit":"true","autoEnableOutline":"false","autoEnableThumbnail":"false","overwritePDFOutline":"false","direction":"1","pageMode":"0","source":"<?=base_url()?>appsources/files/06-Automotive-TEKIRO-Tools.pdf","wpOptions":"true"};</script></p>
<h2 style="text-align: center;">Automotive Tools</h2>
<p style="text-align: center;"><a href="<?=base_url()?>appsources/files/06-Automotive-TEKIRO-Tools.pdf" target="_blank" class="button primary is-primary is-medium"  >
    <span>DOWNLOAD &amp; PRINT</span>
  </a>
</p>

		</div>
	</div>
</div></div></div><div class="wpb_column vc_column_container vc_col-sm-3"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element " >
		<div class="wpb_wrapper">
			<p style="text-align: center;"><div class="_df_thumb " id="df_3160"  wpoptions=true thumb=https://tekiro.com/wp-content/uploads/Storage-1.jpg >Storage</div><script data-cfasync="false">var option_df_3160 = {"outline":[],"forceFit":"true","autoEnableOutline":"false","autoEnableThumbnail":"false","overwritePDFOutline":"false","direction":"1","pageMode":"0","source":"<?=base_url()?>appsources/files/07-Storage-TEKIRO-Tools.pdf","wpOptions":"true"};</script></p>
<h2 style="text-align: center;">Storage</h2>
<p style="text-align: center;"><a href="<?=base_url()?>appsources/files/07-Storage-TEKIRO-Tools.pdf" target="_blank" class="button primary is-primary is-medium"  >
    <span>DOWNLOAD &amp; PRINT</span>
  </a>
</p>

		</div>
	</div>
</div></div></div><div class="wpb_column vc_column_container vc_col-sm-3"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element " >
		<div class="wpb_wrapper">
			<p style="text-align: center;"><div class="_df_thumb " id="df_3162"  wpoptions=true thumb=https://tekiro.com/wp-content/uploads/Tray-1.jpg >Tray</div><script data-cfasync="false">var option_df_3162 = {"outline":[],"forceFit":"true","autoEnableOutline":"false","autoEnableThumbnail":"false","overwritePDFOutline":"false","direction":"1","pageMode":"0","source":"<?=base_url()?>appsources/files/08-Tray-TEKIRO-Tools.pdf","wpOptions":"true"};</script></p>
<h2 style="text-align: center;">Tray</h2>
<p style="text-align: center;"><a href="<?=base_url()?>appsources/files/08-Tray-TEKIRO-Tools.pdf" target="_blank" class="button primary is-primary is-medium"  >
    <span>DOWNLOAD &amp; PRINT</span>
  </a>
</p>

		</div>
	</div>
</div></div></div></div></div></div></div></div><div class="vc_row wpb_row vc_row-fluid vc_custom_1501531556486 vc_row-has-fill"><div class="wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper"><div class="vc_row wpb_row vc_inner vc_row-fluid vc_row-o-equal-height vc_row-o-content-bottom vc_row-flex"><div class="wpb_column vc_column_container vc_col-sm-3"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element " >
		<div class="wpb_wrapper">
			<p style="text-align: center;"><div class="_df_thumb " id="df_3164"  wpoptions=true thumb=https://tekiro.com/wp-content/uploads/Air_tools-1.jpg >Air Tools</div><script data-cfasync="false">var option_df_3164 = {"outline":[],"forceFit":"true","autoEnableOutline":"false","autoEnableThumbnail":"false","overwritePDFOutline":"false","direction":"1","pageMode":"0","source":"<?=base_url()?>appsources/files/09-Air-Tools-TEKIRO-Tools.pdf","wpOptions":"true"};</script></p>
<h2 style="text-align: center;">Air Tools</h2>
<p style="text-align: center;"><a href="<?=base_url()?>appsources/files/09-Air-Tools-TEKIRO-Tools.pdf" target="_blank" class="button primary is-primary is-medium"  >
    <span>DOWNLOAD &amp; PRINT</span>
  </a>
</p>

		</div>
	</div>
</div></div></div><div class="wpb_column vc_column_container vc_col-sm-3"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element " >
		<div class="wpb_wrapper">
			<p style="text-align: center;"><div class="_df_thumb " id="df_3166"  wpoptions=true thumb=https://tekiro.com/wp-content/uploads/Hex_key-1.jpg >Hex Key</div><script data-cfasync="false">var option_df_3166 = {"outline":[],"forceFit":"true","autoEnableOutline":"false","autoEnableThumbnail":"false","overwritePDFOutline":"false","direction":"1","pageMode":"0","source":"<?=base_url()?>appsources/files/10-Hex-Key-TEKIRO-Tools.pdf","wpOptions":"true"};</script></p>
<h2 style="text-align: center;">Hex Key</h2>
<p style="text-align: center;"><a href="<?=base_url()?>appsources/files/10-Hex-Key-TEKIRO-Tools.pdf" target="_blank" class="button primary is-primary is-medium"  >
    <span>DOWNLOAD &amp; PRINT</span>
  </a>
</p>

		</div>
	</div>
</div></div></div><div class="wpb_column vc_column_container vc_col-sm-3"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element " >
		<div class="wpb_wrapper">
			<p style="text-align: center;"><div class="_df_thumb " id="df_3168"  wpoptions=true thumb=https://tekiro.com/wp-content/uploads/General_tools-1.jpg >General Tools</div><script data-cfasync="false">var option_df_3168 = {"outline":[],"forceFit":"true","autoEnableOutline":"false","autoEnableThumbnail":"false","overwritePDFOutline":"false","direction":"1","pageMode":"0","source":"<?=base_url()?>appsources/files/11-General-Tools-TEKIRO-Tools_1.pdf","wpOptions":"true"};</script></p>
<h2 style="text-align: center;">General Tools</h2>
<p style="text-align: center;"><a href="<?=base_url()?>appsources/files/11-General-Tools-TEKIRO-Tools_1.pdf" target="_blank" class="button primary is-primary is-medium"  >
    <span>DOWNLOAD &amp; PRINT</span>
  </a>
</p>

		</div>
	</div>
</div></div></div><div class="wpb_column vc_column_container vc_col-sm-3"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element " >
		<div class="wpb_wrapper">
			<p style="text-align: center;"><div class="_df_thumb " id="df_3170"  wpoptions=true thumb=https://tekiro.com/wp-content/uploads/Special_tools-1.jpg >Special Tools</div><script data-cfasync="false">var option_df_3170 = {"outline":[],"forceFit":"true","autoEnableOutline":"false","autoEnableThumbnail":"false","overwritePDFOutline":"false","direction":"1","pageMode":"0","source":"<?=base_url()?>appsources/files/12-Special-Tools-TEKIRO-Tools.pdf","wpOptions":"true"};</script></p>
<h2 style="text-align: center;">Special Tools</h2>
<p style="text-align: center;"><a href="<?=base_url()?>appsources/files/12-Special-Tools-TEKIRO-Tools.pdf" target="_blank" class="button primary is-primary is-medium"  >
    <span>DOWNLOAD &amp; PRINT</span>
  </a>
</p>

		</div>
	</div>
</div></div></div></div></div></div></div></div><div class="vc_row wpb_row vc_row-fluid vc_custom_1501531592297 vc_row-has-fill"><div class="wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper"><div class="vc_row wpb_row vc_inner vc_row-fluid vc_row-o-equal-height vc_row-o-content-top vc_row-flex"><div class="wpb_column vc_column_container vc_col-sm-3"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element " >
		<div class="wpb_wrapper">
			<p style="text-align: center;"><div class="_df_thumb " id="df_3172"  wpoptions=true thumb=https://tekiro.com/wp-content/uploads/Insulation-1.jpg >Insulation</div><script data-cfasync="false">var option_df_3172 = {"outline":[],"forceFit":"true","autoEnableOutline":"false","autoEnableThumbnail":"false","overwritePDFOutline":"false","direction":"1","pageMode":"0","source":"<?=base_url()?>appsources/files/13-Insulation-TEKIRO-Tools.pdf","wpOptions":"true"};</script></p>
<h2 style="text-align: center;">Insulation</h2>
<p style="text-align: center;"><a href="<?=base_url()?>appsources/files/13-Insulation-TEKIRO-Tools.pdf" target="_blank" class="button primary is-primary is-medium"  >
    <span>DOWNLOAD &amp; PRINT</span>
  </a>
</p>

		</div>
	</div>
</div></div></div><div class="wpb_column vc_column_container vc_col-sm-3"><div class="vc_column-inner "><div class="wpb_wrapper"></div></div></div><div class="wpb_column vc_column_container vc_col-sm-6 vc_col-has-fill"><div class="vc_column-inner vc_custom_1501229791328"><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element " >
		<div class="wpb_wrapper">
			<p><strong><span style="color: #ffffff;">To get full content of TEKIRO Tools Catalogue, please subscribe to our newsletter.<br />
Please fill out the following form to get the latest edition right on your email. Also get the latest updates on TEKIRO products, events and promotions.<br />
</span></strong></p>

	<section id="yikes-mailchimp-container-4" class="yikes-mailchimp-container yikes-mailchimp-container-4 ">
				<form id="product-4" class="yikes-easy-mc-form yikes-easy-mc-form-4  " method="POST" data-attr-form-id="4">

													<label for="yikes-easy-mc-form-4-NAME"  class="NAME-label yikes-mailchimp-field-required ">

										<!-- dictate label visibility -->
										
										<!-- Description Above -->
										
										<input id="yikes-easy-mc-form-4-NAME"  name="NAME"  placeholder="Full Name"  class="yikes-easy-mc-text field-no-label"  required="required" type="text"  value="">

										<!-- Description Below -->
										
									</label>
																		<label for="yikes-easy-mc-form-4-EMAIL"  class="EMAIL-label yikes-mailchimp-field-required ">

										<!-- dictate label visibility -->
										
										<!-- Description Above -->
										
										<input id="yikes-easy-mc-form-4-EMAIL"  name="EMAIL"  placeholder="Email Address"  class="yikes-easy-mc-email field-no-label"  required="required" type="email"  value="">

										<!-- Description Below -->
										
									</label>
									
				<!-- Honeypot Trap -->
				<input type="hidden" name="yikes-mailchimp-honeypot" id="yikes-mailchimp-honeypot" value="">

				<!-- List ID -->
				<input type="hidden" name="yikes-mailchimp-associated-list-id" id="yikes-mailchimp-associated-list-id" value="def53f2e77">

				<!-- The form that is being submitted! Used to display error/success messages above the correct form -->
				<input type="hidden" name="yikes-mailchimp-submitted-form" id="yikes-mailchimp-submitted-form" value="4">

				<!-- Submit Button -->
				<button type="submit" class="yikes-easy-mc-submit-button yikes-easy-mc-submit-button-4 btn btn-primary "> <span class="yikes-mailchimp-submit-button-span-text">Subscribe</span></button>				<!-- Nonce Security Check -->
				<input type="hidden" id="yikes_easy_mc_new_subscriber" name="yikes_easy_mc_new_subscriber" value="78610b29db" /><input type="hidden" name="_wp_http_referer" value="/products/" />
			</form>
			<!-- MailChimp Form generated by Easy Forms for MailChimp v6.3.30 (https://wordpress.org/plugins/yikes-inc-easy-mailchimp-extender/) -->

			</section>
	

		</div>
	</div>
</div></div></div></div></div></div></div></div>

						
												</div><!-- .col-inner -->
		</div><!-- .large-12 -->
	</div><!-- .row -->
</div>


</main>